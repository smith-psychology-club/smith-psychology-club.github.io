---
permalink: /profdevelopment/
title: "Professional Development"
toc_sticky: true
---

# Research
## What is research in psychology
*coming soon...*

## How to get involved in research
*coming soon...*

## How to find jobs or internships in research
### Psychology department mastersheet
The psychology department at Smith College maintains a list of post-bacc research jobs and summer internships. 
<div style="text-align: center"><iframe src="https://docs.google.com/spreadsheets/d/1LuaMWjDd07UBR94SDn0MjhPqaB1gqrv0h3rPE2G73cA/edit?usp=sharing" frameborder="0" width="104%%" height="650" scrolling="yes"></iframe></div>

# Extracurriculars
*coming soon...*
*this section will be about non-research extracurriculars, volunteering, community involvement, etc.*

# Additional guides
## How to: Write a CV
<div style="text-align: center"><iframe src="https://docs.google.com/document/d/1QOwvf5GVvmJmwdPpMHz4DNR53IhmBWZ_SPJiE2S6Le0/edit?usp=sharing" frameborder="0" width="104%%" height="650" scrolling="yes"></iframe></div>

## How to: Send cold emails
<div style="text-align: center"><iframe src="https://docs.google.com/document/d/1Dwx2lKRtH23GHmAd9RiItJrHTYpJ0_GiQzwp1RGp5LQ/edit?usp=sharing" frameborder="0" width="104%%" height="650" scrolling="yes"></iframe></div>

## How to: Find funding
<div style="text-align: center"><iframe src="https://docs.google.com/document/d/1-6nwc5ApUUWtINZQFVwwPG2S4UPFxM-afTK9bv9qr3g/edit?tab=t.0#heading=h.r9jl4n7w57t" frameborder="0" width="104%%" height="650" scrolling="yes"></iframe></div>

## How to: Write a cover letter
*coming soon...*

## How to: Request a letter of reccomendation
*coming soon...*

## How to: Build relevant skills
*coming soon...*
*will have info on building hard skills for free, online, through coursework, etc*

## Tips for interviews
*coming soon...*
